package proyecto.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoDesarolloG3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
